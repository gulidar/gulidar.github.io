+++
date = "2015-07-18T14:08:29+02:00"
draft = false
title = "first"
img = "dog.png"
weight = 1
+++

Here is your fist post.
The img value contain path to the image of this post
Then place a matching image in static/img - e.g. static/img/dog.png
