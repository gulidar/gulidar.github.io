+++
date = "2015-07-18T14:53:21+02:00"
draft = false
title = "third"
img = "phones.png"
weight = 3
+++

Contact buttons will be automatically created if one or more [[params.social]] is configured in config.toml:

title parameter sets the text to be displayed on the contact button
icon parameter sets which Font Awesome icon will be displayed
