+++
date = "2015-07-18T14:08:45+02:00"
draft = false
title = "second"
weight = 2
img = "ipad.png"
+++

Override the default intro and contact backgrounds by putting images in these files:

img/intro-bg.jpg
img/contact-bg.jpg
